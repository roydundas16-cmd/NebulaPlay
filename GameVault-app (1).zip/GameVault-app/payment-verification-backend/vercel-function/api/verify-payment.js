/**
 * verify-payment — Vercel Serverless Function
 *
 * Holds your Stripe SECRET key server-side and checks whether a given
 * Checkout Session was actually paid. The browser never sees the key.
 *
 * SETUP
 * 1. Create a new project at https://vercel.com (or reuse one) and put this
 *    file at:  api/verify-payment.js
 * 2. In the Vercel dashboard: Project Settings -> Environment Variables ->
 *    add STRIPE_SECRET_KEY = your real Stripe secret key (sk_live_... or sk_test_...).
 * 3. Deploy (vercel --prod, or push to the connected git repo).
 * 4. You'll get a URL like:
 *      https://your-project.vercel.app/api/verify-payment
 * 5. Give that URL to the frontend as VERIFY_ENDPOINT.
 *
 * USAGE (from the browser)
 *   GET https://your-project.vercel.app/api/verify-payment?session_id=cs_test_abc123
 *
 * RESPONSE
 *   { "paid": true, "amount_total": 1299, "currency": "usd", "status": "complete" }
 *   or { "paid": false, "status": "open" }
 *   or { "error": "..." } with a 4xx/5xx status
 */

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*"); // tighten to your real domain later
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const sessionId = req.query.session_id;

  if (!sessionId || !sessionId.startsWith("cs_")) {
    return res.status(400).json({ error: "Missing or invalid session_id" });
  }

  const secretKey = process.env.STRIPE_SECRET_KEY;
  if (!secretKey) {
    return res.status(500).json({ error: "Server misconfigured: STRIPE_SECRET_KEY not set" });
  }

  const stripeRes = await fetch(
    `https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(sessionId)}`,
    { headers: { Authorization: `Bearer ${secretKey}` } }
  );

  if (!stripeRes.ok) {
    const detail = await stripeRes.text();
    return res.status(stripeRes.status).json({ error: "Stripe lookup failed", detail });
  }

  const session = await stripeRes.json();

  return res.status(200).json({
    paid: session.payment_status === "paid",
    status: session.status,
    amount_total: session.amount_total,
    currency: session.currency,
  });
}

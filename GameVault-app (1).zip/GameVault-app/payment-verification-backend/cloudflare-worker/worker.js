/**
 * verify-payment — Cloudflare Worker
 *
 * Holds your Stripe SECRET key server-side and checks whether a given
 * Checkout Session was actually paid. The browser never sees the key.
 *
 * SETUP
 * 1. Go to https://dash.cloudflare.com -> Workers & Pages -> Create -> Worker
 * 2. Paste this file's contents in as the worker code.
 * 3. Go to Settings -> Variables and Secrets -> add a secret named
 *    STRIPE_SECRET_KEY with your real Stripe secret key (starts with sk_live_
 *    or sk_test_). Mark it "encrypted".
 * 4. Deploy. You'll get a URL like:
 *      https://verify-payment.<your-subdomain>.workers.dev
 * 5. Give that URL to the frontend as VERIFY_ENDPOINT.
 *
 * USAGE (from the browser)
 *   GET https://verify-payment.<you>.workers.dev/?session_id=cs_test_abc123
 *
 * RESPONSE
 *   { "paid": true, "amount_total": 1299, "currency": "usd", "status": "complete" }
 *   or { "paid": false, "status": "open" }
 *   or { "error": "..." } with a 4xx/5xx status
 */

const ALLOWED_ORIGIN = "*"; // tighten this to your app's real domain once you have one

function withCors(response) {
  const headers = new Headers(response.headers);
  headers.set("Access-Control-Allow-Origin", ALLOWED_ORIGIN);
  headers.set("Access-Control-Allow-Methods", "GET, OPTIONS");
  headers.set("Access-Control-Allow-Headers", "Content-Type");
  return new Response(response.body, { status: response.status, headers });
}

function json(data, status = 200) {
  return withCors(
    new Response(JSON.stringify(data), {
      status,
      headers: { "Content-Type": "application/json" },
    })
  );
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return withCors(new Response(null, { status: 204 }));
    }

    if (request.method !== "GET") {
      return json({ error: "Method not allowed" }, 405);
    }

    const url = new URL(request.url);
    const sessionId = url.searchParams.get("session_id");

    if (!sessionId || !sessionId.startsWith("cs_")) {
      return json({ error: "Missing or invalid session_id" }, 400);
    }

    if (!env.STRIPE_SECRET_KEY) {
      return json({ error: "Server misconfigured: STRIPE_SECRET_KEY not set" }, 500);
    }

    const stripeRes = await fetch(
      `https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(sessionId)}`,
      {
        headers: {
          Authorization: `Bearer ${env.STRIPE_SECRET_KEY}`,
        },
      }
    );

    if (!stripeRes.ok) {
      const errBody = await stripeRes.text();
      return json({ error: "Stripe lookup failed", detail: errBody }, stripeRes.status);
    }

    const session = await stripeRes.json();

    return json({
      paid: session.payment_status === "paid",
      status: session.status,
      amount_total: session.amount_total,
      currency: session.currency,
    });
  },
};

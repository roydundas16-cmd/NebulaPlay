# Payment verification backend

Two ready-to-deploy options that do the same thing. Pick ONE.

- `cloudflare-worker/worker.js` — deploy on Cloudflare Workers (free tier is generous)
- `vercel-function/api/verify-payment.js` — deploy on Vercel (free tier is generous)

Both hold your Stripe **secret key** server-side and expose one endpoint:

```
GET <your-deployed-url>?session_id=cs_test_abc123
```

which returns:

```json
{ "paid": true, "status": "complete", "amount_total": 1299, "currency": "usd" }
```

Deployment steps are in the comment block at the top of each file.

## Wiring this into GameVault.jsx (next step, not done yet)

This part still needs your deployed URL before it can be built, plus one
setting on each Stripe Payment Link:

1. In Stripe, edit each Payment Link -> "After payment" -> redirect to a URL,
   and use `{CHECKOUT_SESSION_ID}` in it, e.g.
   `https://your-app-url/?session_id={CHECKOUT_SESSION_ID}`
2. Once you have both the deployed verify-payment URL and that redirect set
   up, send me the URL and I'll update GameVault.jsx to:
   - read `session_id` from the page URL on load
   - call your endpoint to check `paid: true`
   - unlock the game/subscription automatically, only if Stripe confirms it

Until that's wired in, GameVault.jsx still uses the manual
"I've completed payment" button as a placeholder.

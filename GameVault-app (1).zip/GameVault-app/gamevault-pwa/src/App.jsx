import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  Home as HomeIcon, Search as SearchIcon, PlusSquare, MessageSquare, Crown,
  User as UserIcon, Rocket, Sparkles, Lock, Download, ArrowLeft, Tag,
  ShieldCheck, Star, Check, TrendingUp, Trophy, MessageCirclePlus, Send,
  LogOut, LayoutDashboard, UploadCloud, Image as ImageIcon, Loader2, X,
  Gamepad2, Eye, ChevronRight,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Design tokens                                                      */
/* ------------------------------------------------------------------ */
const C = {
  bg: "#0a0c12",
  bgSoft: "#0e111a",
  card: "rgba(255,255,255,0.045)",
  cardBorder: "rgba(255,255,255,0.09)",
  blueA: "#00A8FF",
  blueB: "#0070D1",
  text: "#f4f6f9",
  dim: "#8a93a6",
  dim2: "#5b6478",
  emerald: "#34d399",
  amber: "#fbbf24",
  red: "#f87171",
};

const glass = {
  background: C.card,
  backdropFilter: "blur(20px)",
  WebkitBackdropFilter: "blur(20px)",
  border: `1px solid ${C.cardBorder}`,
};
const gradBg = { backgroundImage: `linear-gradient(90deg, ${C.blueB}, ${C.blueA})` };
const glow = { boxShadow: "0 0 26px rgba(0,168,255,0.28)" };
const gradText = {
  backgroundImage: `linear-gradient(90deg, ${C.blueA}, ${C.blueB})`,
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
};

/* ------------------------------------------------------------------ */
/*  Seed data                                                          */
/* ------------------------------------------------------------------ */
const CATEGORIES = ["Action", "Adventure", "RPG", "Strategy", "Sports", "Racing", "Puzzle", "Horror", "Simulation", "Other"];
const TYPES = ["PC", "Console", "Mobile", "Browser", "VR", "Indie"];

const IMG = {
  fallback: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&q=80",
};

// No sample content — the app starts empty. Everything shown is created
// by whoever is using it (games, reviews, chat messages, etc).
const seedGames = [];
const seedReviews = {};
const seedPublicChat = [];
const seedConversations = [];

const initialUser = {
  id: "u1",
  full_name: "You",
  email: "",
  subscription_plan: "none",
  subscription_status: "inactive",
  billing_cycle: "monthly",
  trial_end_date: null,
  is_creator: true,
};

/* ------------------------------------------------------------------ */
/*  Small UI atoms                                                     */
/* ------------------------------------------------------------------ */
function GlassCard({ className = "", style, children, ...rest }) {
  return (
    <div className={className} style={{ ...glass, borderRadius: "1.25rem", ...style }} {...rest}>
      {children}
    </div>
  );
}

function GradButton({ className = "", style, children, ...rest }) {
  return (
    <button
      className={`rounded-full font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50 ${className}`}
      style={{ ...gradBg, ...glow, ...style }}
      {...rest}
    >
      {children}
    </button>
  );
}

function GhostButton({ className = "", style, children, ...rest }) {
  return (
    <button
      className={`rounded-full font-medium transition-colors ${className}`}
      style={{ ...glass, color: C.dim, ...style }}
      {...rest}
    >
      {children}
    </button>
  );
}

function Toast({ toast }) {
  if (!toast) return null;
  return (
    <div className="fixed top-5 right-5 z-[100] px-5 py-3 rounded-2xl text-sm font-medium text-white shadow-2xl" style={{ ...glass, ...glow }}>
      <div className="font-semibold" style={{ color: C.text }}>{toast.title}</div>
      {toast.description && <div className="text-xs mt-0.5" style={{ color: C.dim }}>{toast.description}</div>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Nav                                                                 */
/* ------------------------------------------------------------------ */
const NAV = [
  { label: "Home", page: "home", icon: HomeIcon },
  { label: "Search", page: "search", icon: SearchIcon },
  { label: "Launcher", page: "library", icon: Rocket },
  { label: "Add Game", page: "add-game", icon: PlusSquare },
  { label: "Community", page: "community", icon: MessageSquare },
  { label: "Plans", page: "subscription", icon: Crown },
  { label: "Profile", page: "profile", icon: UserIcon },
];

function SideNav({ page, go }) {
  return (
    <aside className="hidden md:flex flex-col w-60 shrink-0 h-screen sticky top-0 px-4 py-6" style={{ ...glass, borderRadius: 0, borderRight: `1px solid ${C.cardBorder}` }}>
      <div className="mb-10 px-2 flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={gradBg}>
          <Gamepad2 className="w-4.5 h-4.5 text-white" style={{ width: 18, height: 18 }} />
        </div>
        <span className="text-xl font-black tracking-tight" style={gradText}>GameVault</span>
      </div>
      <nav className="flex flex-col gap-1">
        {NAV.map(({ label, page: p, icon: Icon }) => {
          const active = page === p;
          return (
            <button
              key={p}
              onClick={() => go(p)}
              className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-left transition-all"
              style={active ? { ...gradBg, ...glow, color: "#fff", fontWeight: 600 } : { color: C.dim }}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          );
        })}
      </nav>
      <div className="mt-auto px-2 text-[11px]" style={{ color: C.dim2 }}>Standalone preview build</div>
    </aside>
  );
}

function BottomNav({ page, go }) {
  const items = NAV.filter((n) => n.page !== "search");
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 px-1 py-2 flex justify-around" style={{ ...glass, borderRadius: 0, borderTop: `1px solid ${C.cardBorder}` }}>
      {items.map(({ label, page: p, icon: Icon }) => {
        const active = page === p;
        return (
          <button key={p} onClick={() => go(p)} className="flex flex-col items-center gap-1 px-2 py-1.5 rounded-lg" style={{ color: active ? C.blueA : C.dim2 }}>
            <Icon className="w-5 h-5" />
            <span className="text-[9px] font-medium">{label}</span>
          </button>
        );
      })}
    </nav>
  );
}

/* ------------------------------------------------------------------ */
/*  Game components                                                     */
/* ------------------------------------------------------------------ */
function GameCard({ game, go }) {
  const [hover, setHover] = useState(false);
  return (
    <button
      onClick={() => go("game-detail", { id: game.id })}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      className="text-left rounded-2xl overflow-hidden transition-transform duration-300"
      style={{ ...glass, transform: hover ? "translateY(-4px)" : "none", borderColor: hover ? "rgba(0,168,255,0.5)" : C.cardBorder, boxShadow: hover ? "0 0 26px rgba(0,168,255,0.28)" : "none" }}
    >
      <div className="relative aspect-[16/10] overflow-hidden" style={{ background: "rgba(255,255,255,0.05)" }}>
        <img src={game.cover_image_url} alt={game.title} className="w-full h-full object-cover" style={{ transform: hover ? "scale(1.06)" : "scale(1)", transition: "transform .5s" }} />
        <div className="absolute top-2 right-2 px-2 py-1 rounded-full text-xs font-semibold flex items-center gap-1" style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(6px)", color: game.is_paid ? C.blueA : C.emerald }}>
          {game.is_paid ? (<><Lock className="w-3 h-3" /> ${Number(game.price).toFixed(2)}</>) : "Free"}
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold truncate" style={{ color: C.text }}>{game.title}</h3>
        <p className="text-xs mt-1 flex items-center gap-2" style={{ color: C.dim }}>
          <span>{game.category}</span><span className="w-1 h-1 rounded-full" style={{ background: C.dim2 }} /><span>{game.type}</span>
        </p>
        <div className="flex items-center gap-1 mt-3 text-[10px]" style={{ color: C.dim2 }}>
          <ShieldCheck className="w-3 h-3" /> Protected content
        </div>
      </div>
    </button>
  );
}

function GameSection({ title, games, go }) {
  if (!games?.length) return null;
  return (
    <section className="mb-10">
      <h2 className="text-xl font-black tracking-tight mb-4" style={{ color: C.text }}>{title}</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {games.map((g) => <GameCard key={g.id} game={g} go={go} />)}
      </div>
    </section>
  );
}

function FilterBar({ query, setQuery, type, setType, category, setCategory }) {
  const [typeOpen, setTypeOpen] = useState(false);
  const [catOpen, setCatOpen] = useState(false);
  return (
    <div className="flex flex-col sm:flex-row gap-3 mb-8 relative">
      <div className="relative flex-1">
        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: C.dim2 }} />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search games..."
          className="w-full rounded-full pl-11 pr-4 py-3 text-sm outline-none"
          style={{ ...glass, color: C.text }}
        />
      </div>
      <div className="relative">
        <GhostButton className="px-5 py-3 text-sm w-full sm:w-auto" onClick={() => { setTypeOpen((v) => !v); setCatOpen(false); }}>
          Type{type !== "All" ? `: ${type}` : ""}
        </GhostButton>
        {typeOpen && (
          <div className="absolute mt-2 right-0 z-20 rounded-xl overflow-hidden w-40" style={glass}>
            {["All", ...TYPES].map((t) => (
              <div key={t} onClick={() => { setType(t); setTypeOpen(false); }} className="px-4 py-2 text-sm cursor-pointer hover:bg-white/10" style={{ color: C.text }}>{t}</div>
            ))}
          </div>
        )}
      </div>
      <div className="relative">
        <GhostButton className="px-5 py-3 text-sm w-full sm:w-auto" onClick={() => { setCatOpen((v) => !v); setTypeOpen(false); }}>
          Category{category !== "All" ? `: ${category}` : ""}
        </GhostButton>
        {catOpen && (
          <div className="absolute mt-2 right-0 z-20 rounded-xl overflow-hidden w-44 max-h-64 overflow-y-auto" style={glass}>
            {["All", ...CATEGORIES].map((c) => (
              <div key={c} onClick={() => { setCategory(c); setCatOpen(false); }} className="px-4 py-2 text-sm cursor-pointer hover:bg-white/10" style={{ color: C.text }}>{c}</div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StarRatingInput({ value, onChange }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((n) => (
        <button key={n} type="button" onClick={() => onChange(n)} onMouseEnter={() => setHover(n)} onMouseLeave={() => setHover(0)}>
          <Star className="w-6 h-6 transition-colors" style={{ color: (hover || value) >= n ? C.blueA : C.dim2, fill: (hover || value) >= n ? C.blueA : "none" }} />
        </button>
      ))}
    </div>
  );
}

function CheckoutModal({ open, price, link, onClose, onConfirm }) {
  const [redirected, setRedirected] = useState(false);
  if (!open) return null;

  const handleGoToStripe = () => {
    window.open(link, "_blank", "noopener,noreferrer");
    setRedirected(true);
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.6)" }} onClick={onClose}>
      <div className="w-full max-w-md rounded-3xl p-6" style={glass} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="flex items-center gap-2 font-bold" style={{ color: C.text }}><Lock className="w-4 h-4" style={{ color: C.blueA }} /> Checkout</h3>
          <button onClick={onClose} style={{ color: C.dim }}><X className="w-4 h-4" /></button>
        </div>

        <div className="flex justify-between items-center mb-5">
          <span className="text-sm" style={{ color: C.dim }}>Total</span>
          <span className="text-xl font-bold" style={{ color: C.text }}>${Number(price).toFixed(2)}</span>
        </div>

        {!link ? (
          <p className="text-sm text-center py-4" style={{ color: C.dim }}>
            No Stripe Payment Link has been set up for this yet. Add one from the creator side to accept real payments.
          </p>
        ) : !redirected ? (
          <>
            <GradButton onClick={handleGoToStripe} className="w-full py-3">
              Continue to Stripe
            </GradButton>
            <p className="text-[11px] text-center mt-3" style={{ color: C.dim2 }}>
              Opens Stripe's secure checkout in a new tab. Your card details are entered there, never here.
            </p>
          </>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-center" style={{ color: C.dim }}>
              Finish the payment in the Stripe tab, then confirm below to unlock.
            </p>
            <GhostButton onClick={handleGoToStripe} className="w-full py-2.5 text-sm" style={{ color: "#c7cddb" }}>
              Reopen Stripe checkout
            </GhostButton>
            <GradButton onClick={() => onConfirm()} className="w-full py-3">
              I've completed payment
            </GradButton>
          </div>
        )}
      </div>
    </div>
  );
}

function GameReviews({ gameId, reviews, addReview, currentUser }) {
  const list = reviews[gameId] || [];
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const avg = list.length ? (list.reduce((s, r) => s + r.rating, 0) / list.length).toFixed(1) : null;

  const submit = async (e) => {
    e.preventDefault();
    if (!rating) return;
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 350));
    addReview(gameId, { id: `r_${Date.now()}`, user_name: currentUser.full_name, rating, comment });
    setRating(0); setComment(""); setSubmitting(false);
  };

  return (
    <div className="mt-8">
      <div className="flex items-center gap-2 mb-4">
        <h2 className="text-lg font-bold" style={{ color: C.text }}>Ratings & Reviews</h2>
        {avg && <span className="flex items-center gap-1 text-sm font-semibold" style={{ color: C.blueA }}><Star className="w-4 h-4" style={{ fill: C.blueA }} /> {avg} ({list.length})</span>}
      </div>
      <form onSubmit={submit} className="rounded-2xl p-5 mb-6 space-y-3" style={glass}>
        <p className="text-sm" style={{ color: C.dim }}>Leave your feedback after playing</p>
        <StarRatingInput value={rating} onChange={setRating} />
        <textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Share your thoughts on this game..." rows={3} className="w-full rounded-xl px-4 py-2.5 text-sm outline-none" style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.cardBorder}`, color: C.text }} />
        <GradButton type="submit" disabled={!rating || submitting} className="px-6 py-2.5 text-sm">
          {submitting ? "Submitting..." : "Submit Review"}
        </GradButton>
      </form>
      <div className="space-y-3">
        {list.map((r) => (
          <div key={r.id} className="rounded-2xl p-4" style={glass}>
            <div className="flex items-center justify-between mb-1">
              <span className="font-semibold text-sm" style={{ color: C.text }}>{r.user_name}</span>
              <div className="flex gap-0.5">
                {[1, 2, 3, 4, 5].map((n) => <Star key={n} className="w-3.5 h-3.5" style={{ color: r.rating >= n ? C.blueA : C.dim2, fill: r.rating >= n ? C.blueA : "none" }} />)}
              </div>
            </div>
            {r.comment && <p className="text-sm" style={{ color: C.dim }}>{r.comment}</p>}
          </div>
        ))}
        {list.length === 0 && <p className="text-sm text-center py-6" style={{ color: C.dim2 }}>No reviews yet. Be the first to share your feedback.</p>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Pages                                                               */
/* ------------------------------------------------------------------ */
function HomePage({ games, go }) {
  const [query, setQuery] = useState("");
  const [type, setType] = useState("All");
  const [category, setCategory] = useState("All");

  const filtered = games.filter((g) => {
    const mq = g.title.toLowerCase().includes(query.toLowerCase());
    const mt = type === "All" || g.type === type;
    const mc = category === "All" || g.category === category;
    return mq && mt && mc;
  });
  const filtering = query || type !== "All" || category !== "All";

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="rounded-3xl p-8 mb-10 relative overflow-hidden" style={glass}>
        <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full blur-3xl" style={{ background: "rgba(0,112,209,0.3)" }} />
        <div className="relative">
          <h1 className="text-3xl md:text-4xl font-black tracking-tight mb-2" style={{ color: C.text }}>
            Welcome back to <span style={gradText}>GameVault</span>
          </h1>
          <p className="mb-6 max-w-xl" style={{ color: C.dim }}>
            Discover indie games, connect with creators, and build your own library — all in one place.
          </p>
          <GradButton className="px-6 py-3 inline-flex items-center" onClick={() => go("add-game")}>
            <Sparkles className="w-4 h-4 mr-2" /> Publish your first game
          </GradButton>
        </div>
      </div>

      <FilterBar query={query} setQuery={setQuery} type={type} setType={setType} category={category} setCategory={setCategory} />

      {filtering ? (
        <GameSection title={`Results (${filtered.length})`} games={filtered} go={go} />
      ) : (
        <>
          <GameSection title="Featured Games" games={games.slice(0, 4)} go={go} />
          <GameSection title="Trending Now" games={[...games].sort((a, b) => b.view_count - a.view_count).slice(0, 4)} go={go} />
          <GameSection title="Recently Added" games={games.slice().reverse().slice(0, 8)} go={go} />
        </>
      )}
    </div>
  );
}

function SearchPage({ games, go }) {
  const [query, setQuery] = useState("");
  const [type, setType] = useState("All");
  const [category, setCategory] = useState("All");
  const filtered = games.filter((g) => {
    const mq = g.title.toLowerCase().includes(query.toLowerCase());
    const mt = type === "All" || g.type === type;
    const mc = category === "All" || g.category === category;
    return mq && mt && mc;
  });
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-3xl font-black mb-6" style={{ color: C.text }}>Search Games</h1>
      <FilterBar query={query} setQuery={setQuery} type={type} setType={setType} category={category} setCategory={setCategory} />
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filtered.map((g) => <GameCard key={g.id} game={g} go={go} />)}
      </div>
      {filtered.length === 0 && <div className="text-center py-20" style={{ color: C.dim2 }}>No games match your search.</div>}
    </div>
  );
}

function GameDetailPage({ id, games, setGames, reviews, addReview, currentUser, purchases, addPurchase, go, toast }) {
  const game = games.find((g) => g.id === id);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const hasAccess = !game?.is_paid || purchases.some((p) => p.game_id === id);

  useEffect(() => {
    if (!game) return;
    setGames((prev) => prev.map((g) => (g.id === id ? { ...g, view_count: g.view_count + 1 } : g)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!game) return <div className="p-10" style={{ color: C.dim }}>Game not found.</div>;

  const confirmPurchase = () => {
    addPurchase({ game_id: id, buyer_id: currentUser.id, amount: game.price });
    setGames((prev) => prev.map((g) => (g.id === id ? { ...g, purchase_count: g.purchase_count + 1 } : g)));
    setCheckoutOpen(false);
    toast({ title: "Purchase complete", description: `${game.title} unlocked.` });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <button onClick={() => go("home")} className="flex items-center gap-2 mb-6 text-sm" style={{ color: C.dim }}>
        <ArrowLeft className="w-4 h-4" /> Back
      </button>

      <div className="rounded-3xl overflow-hidden mb-8" style={glass}>
        <img src={game.cover_image_url} alt={game.title} className="w-full h-64 md:h-80 object-cover" />
      </div>

      <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 mb-8">
        <div>
          <h1 className="text-3xl font-black mb-2" style={{ color: C.text }}>{game.title}</h1>
          <div className="flex items-center gap-2 text-sm" style={{ color: C.dim }}>
            <span>{game.category}</span><span className="w-1 h-1 rounded-full" style={{ background: C.dim2 }} /><span>{game.type}</span>
            <span className="w-1 h-1 rounded-full" style={{ background: C.dim2 }} /><span>{game.creator_name}</span>
          </div>
        </div>
        {game.is_paid && !hasAccess && (
          <GradButton onClick={() => setCheckoutOpen(true)} className="px-6 py-3 inline-flex items-center">
            <Lock className="w-4 h-4 mr-2" /> Unlock for ${Number(game.price).toFixed(2)}
          </GradButton>
        )}
        {hasAccess && (
          <button
            onClick={() => toast({ title: "Launching…", description: `${game.title} started (demo mode).` })}
            className="rounded-full px-6 py-3 font-semibold text-white inline-flex items-center"
            style={{ background: C.emerald }}
          >
            <Download className="w-4 h-4 mr-2" /> Access Game
          </button>
        )}
      </div>

      <p className="leading-relaxed mb-6" style={{ color: "#c7cddb" }}>{game.description}</p>

      {game.tags?.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-8">
          {game.tags.map((t) => (
            <span key={t} className="flex items-center gap-1 text-xs px-3 py-1 rounded-full" style={{ background: "rgba(255,255,255,0.06)", color: C.dim }}>
              <Tag className="w-3 h-3" /> {t}
            </span>
          ))}
        </div>
      )}

      <GlassCard className="p-5 flex items-start gap-3 text-sm">
        <ShieldCheck className="w-5 h-5 shrink-0 mt-0.5" style={{ color: C.blueA }} />
        <div>
          <p className="font-semibold mb-1" style={{ color: C.text }}>Protected Creator Content</p>
          <p style={{ color: C.dim }}>© All rights reserved by the creator. Unauthorized reposting, duplication, or redistribution of this game is prohibited. Access is limited to authorized purchasers only.</p>
        </div>
      </GlassCard>

      <CheckoutModal open={checkoutOpen} price={game.price} link={game.stripe_link} onClose={() => setCheckoutOpen(false)} onConfirm={confirmPurchase} />
      <GameReviews gameId={id} reviews={reviews} addReview={addReview} currentUser={currentUser} />
    </div>
  );
}

function AddGamePage({ addGame, currentUser, go, toast }) {
  const [form, setForm] = useState({ title: "", description: "", category: "Action", type: "PC", tags: "", cover_image_url: "", is_paid: false, price: "", stripe_link: "" });
  const [coverPreview, setCoverPreview] = useState("");
  const [saving, setSaving] = useState(false);
  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleCover = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setCoverPreview(url);
    update("cover_image_url", url);
  };

  const submit = (e) => {
    e.preventDefault();
    setSaving(true);
    setTimeout(() => {
      addGame({
        id: `g_${Date.now()}`,
        title: form.title,
        description: form.description,
        category: form.category,
        type: form.type,
        tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean),
        cover_image_url: form.cover_image_url || IMG.fallback,
        is_paid: form.is_paid,
        price: form.is_paid ? Number(form.price) || 0 : 0,
        stripe_link: form.is_paid ? form.stripe_link.trim() : "",
        view_count: 0,
        purchase_count: 0,
        creator_name: currentUser.full_name,
        publication_status: "published",
      });
      setSaving(false);
      toast({ title: "Game published!", description: `${form.title} is now live.` });
      go("home");
    }, 500);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-3xl font-black mb-1" style={{ color: C.text }}>Add Game</h1>
      <p className="mb-8" style={{ color: C.dim }}>Publish your game to the GameVault community.</p>

      <form onSubmit={submit} className="space-y-6 rounded-3xl p-6" style={glass}>
        <div>
          <label className="text-xs" style={{ color: C.dim }}>Title</label>
          <input required value={form.title} onChange={(e) => update("title", e.target.value)} placeholder="Game title" className="w-full mt-1 rounded-xl px-4 py-2.5 text-sm outline-none" style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.cardBorder}`, color: C.text }} />
        </div>
        <div>
          <label className="text-xs" style={{ color: C.dim }}>Description</label>
          <textarea required rows={4} value={form.description} onChange={(e) => update("description", e.target.value)} placeholder="Describe your game" className="w-full mt-1 rounded-xl px-4 py-2.5 text-sm outline-none" style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.cardBorder}`, color: C.text }} />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs" style={{ color: C.dim }}>Category</label>
            <select value={form.category} onChange={(e) => update("category", e.target.value)} className="w-full mt-1 rounded-xl px-4 py-2.5 text-sm outline-none" style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.cardBorder}`, color: C.text }}>
              {CATEGORIES.map((c) => <option key={c} value={c} style={{ background: C.bgSoft }}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs" style={{ color: C.dim }}>Type</label>
            <select value={form.type} onChange={(e) => update("type", e.target.value)} className="w-full mt-1 rounded-xl px-4 py-2.5 text-sm outline-none" style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.cardBorder}`, color: C.text }}>
              {TYPES.map((t) => <option key={t} value={t} style={{ background: C.bgSoft }}>{t}</option>)}
            </select>
          </div>
        </div>
        <div>
          <label className="text-xs" style={{ color: C.dim }}>Tags (comma separated)</label>
          <input value={form.tags} onChange={(e) => update("tags", e.target.value)} placeholder="multiplayer, retro, indie" className="w-full mt-1 rounded-xl px-4 py-2.5 text-sm outline-none" style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.cardBorder}`, color: C.text }} />
        </div>

        <div>
          <label className="text-xs mb-2 block" style={{ color: C.dim }}>Cover Image</label>
          <label className="flex items-center gap-3 rounded-xl p-4 cursor-pointer" style={glass}>
            {coverPreview ? <img src={coverPreview} className="w-10 h-10 rounded-lg object-cover" /> : <ImageIcon className="w-5 h-5" style={{ color: C.blueA }} />}
            <span className="text-sm" style={{ color: C.dim }}>{coverPreview ? "Cover selected ✓" : "Upload cover image"}</span>
            <input type="file" accept="image/*" className="hidden" onChange={handleCover} />
          </label>
        </div>

        <div className="flex items-center justify-between rounded-xl p-4" style={glass}>
          <div>
            <p className="font-medium" style={{ color: C.text }}>Paid Game</p>
            <p className="text-xs" style={{ color: C.dim2 }}>Requires checkout to unlock</p>
          </div>
          <button type="button" onClick={() => update("is_paid", !form.is_paid)} className="w-12 h-7 rounded-full relative transition-colors" style={{ background: form.is_paid ? C.blueA : "rgba(255,255,255,0.15)" }}>
            <span className="absolute top-0.5 w-6 h-6 rounded-full bg-white transition-transform" style={{ transform: form.is_paid ? "translateX(22px)" : "translateX(2px)" }} />
          </button>
        </div>

        {form.is_paid && (
          <>
            <div>
              <label className="text-xs" style={{ color: C.dim }}>Price (USD)</label>
              <input required type="number" min="0" step="0.01" value={form.price} onChange={(e) => update("price", e.target.value)} placeholder="9.99" className="w-full mt-1 rounded-xl px-4 py-2.5 text-sm outline-none" style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.cardBorder}`, color: C.text }} />
            </div>
            <div>
              <label className="text-xs" style={{ color: C.dim }}>Stripe Payment Link</label>
              <input type="url" value={form.stripe_link} onChange={(e) => update("stripe_link", e.target.value)} placeholder="https://buy.stripe.com/..." className="w-full mt-1 rounded-xl px-4 py-2.5 text-sm outline-none" style={{ background: "rgba(255,255,255,0.05)", border: `1px solid ${C.cardBorder}`, color: C.text }} />
              <p className="text-[11px] mt-1.5" style={{ color: C.dim2 }}>
                Create one at <span style={{ color: C.blueA }}>dashboard.stripe.com/payment-links</span> for this price. Buyers get sent there to pay for real — no card details ever touch this app. Leave blank to publish without checkout enabled yet.
              </p>
            </div>
          </>
        )}

        <GradButton type="submit" disabled={saving} className="w-full py-3">
          {saving ? "Publishing..." : "Save & Publish Game"}
        </GradButton>
      </form>
    </div>
  );
}

function LibraryPage({ games, purchases, currentUser, toast }) {
  const owned = games.filter((g) => !g.is_paid || purchases.some((p) => p.game_id === g.id));
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-black" style={{ color: C.text }}>Launcher</h1>
        <p className="text-sm mt-1" style={{ color: C.dim }}>Launch any game you own, right from your library.</p>
      </div>
      {owned.length === 0 ? (
        <GlassCard className="text-center py-20">
          <Gamepad2 className="w-10 h-10 mx-auto mb-3" style={{ color: C.dim2 }} />
          <p style={{ color: C.dim }}>No games in your library yet.</p>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {owned.map((g) => (
            <GlassCard key={g.id} className="p-4 flex items-center gap-4">
              <img src={g.cover_image_url} alt={g.title} className="w-16 h-16 rounded-xl object-cover shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-semibold truncate" style={{ color: C.text }}>{g.title}</p>
                <p className="text-xs" style={{ color: C.dim }}>{g.category} · {g.type}</p>
              </div>
              <GradButton className="px-5 py-2.5 text-sm inline-flex items-center shrink-0" onClick={() => toast({ title: "Launching…", description: `${g.title} started (demo mode).` })}>
                <Rocket className="w-4 h-4 mr-2" /> Launch
              </GradButton>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}

function PricingCard({ plan, price, features, best, current, onSelect }) {
  return (
    <div className="relative rounded-3xl p-6 flex flex-col" style={{ ...glass, ...(best ? { borderColor: "rgba(0,168,255,0.6)", ...glow, transform: "scale(1.03)" } : {}) }}>
      {best && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-white text-xs font-bold px-4 py-1 rounded-full flex items-center gap-1" style={gradBg}>
          <Crown className="w-3 h-3" /> BEST VALUE
        </div>
      )}
      <h3 className="text-xl font-black mt-2" style={{ color: C.text }}>{plan}</h3>
      <div className="my-4">
        <span className="text-4xl font-black" style={{ color: C.text }}>${price}</span>
        <span className="text-sm" style={{ color: C.dim }}>/mo</span>
      </div>
      <ul className="space-y-2 mb-6 flex-1">
        {features.map((f) => (
          <li key={f} className="flex items-start gap-2 text-sm" style={{ color: "#c7cddb" }}>
            <Check className="w-4 h-4 mt-0.5 shrink-0" style={{ color: C.blueA }} /> {f}
          </li>
        ))}
      </ul>
      {best ? (
        <GradButton onClick={onSelect} disabled={current} className="w-full py-3">{current ? "Current Plan" : "Upgrade Now"}</GradButton>
      ) : (
        <GhostButton onClick={onSelect} disabled={current} className="w-full py-3" style={{ background: "rgba(255,255,255,0.08)", color: C.text, border: "none" }}>
          {current ? "Current Plan" : "Upgrade Now"}
        </GhostButton>
      )}
    </div>
  );
}

// Fill these in with real Stripe Payment Links from dashboard.stripe.com/payment-links
// (one link per price — monthly and yearly are usually separate prices in Stripe).
const PLANS = [
  { key: "basic", plan: "Basic", monthly: 4.99, yearly: 49, stripe_link_monthly: "", stripe_link_yearly: "", features: ["Access to free games", "Basic messaging", "Standard support"] },
  { key: "pro", plan: "Pro", monthly: 9.99, yearly: 99, stripe_link_monthly: "", stripe_link_yearly: "", features: ["Everything in Basic", "Priority messaging", "Early access to new games", "No purchase fees"] },
  { key: "premium", plan: "Premium", monthly: 14.99, yearly: 149, stripe_link_monthly: "", stripe_link_yearly: "", features: ["Everything in Pro", "Exclusive premium games", "Direct creator support", "Ad-free experience"], best: true },
];
const LOCKED_FEATURES = ["Exclusive premium-only games", "Priority creator messaging", "Early access releases", "Ad-free browsing", "Reduced purchase fees"];

function SubscriptionPage({ user, setUser, toast }) {
  const [yearly, setYearly] = useState(false);
  const [checkoutPlan, setCheckoutPlan] = useState(null);

  const startTrial = () => {
    const end = new Date();
    end.setDate(end.getDate() + 7);
    setUser((u) => ({ ...u, subscription_status: "trial", trial_end_date: end.toISOString() }));
    toast({ title: "Free trial started!", description: "Enjoy 7 days of premium access." });
  };

  const confirm = () => {
    setUser((u) => ({ ...u, subscription_plan: checkoutPlan.key, subscription_status: "active", billing_cycle: yearly ? "yearly" : "monthly" }));
    toast({ title: "Subscription active!", description: `You're now on the ${checkoutPlan.plan} plan.` });
    setCheckoutPlan(null);
  };

  const trialDaysLeft = user.trial_end_date ? Math.ceil((new Date(user.trial_end_date) - new Date()) / 86400000) : null;
  const isNew = user.subscription_status === "inactive";

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-3xl font-black mb-2" style={{ color: C.text }}>Subscription</h1>
      <p className="mb-8" style={{ color: C.dim }}>Unlock the full GameVault experience.</p>

      {isNew && (
        <GlassCard className="p-6 mb-8 flex flex-col sm:flex-row items-center justify-between gap-4" style={{ borderColor: "rgba(0,168,255,0.3)" }}>
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6" style={{ color: C.blueA }} />
            <div>
              <p className="font-bold" style={{ color: C.text }}>Start your 7-day free trial</p>
              <p className="text-sm" style={{ color: C.dim }}>Full premium access, no commitment.</p>
            </div>
          </div>
          <GradButton className="px-6 py-3" onClick={startTrial}>Start Free Trial</GradButton>
        </GlassCard>
      )}

      {user.subscription_status === "trial" && trialDaysLeft !== null && (
        <GlassCard className="p-4 mb-8 text-sm font-medium" style={{ color: C.blueA }}>
          {trialDaysLeft > 0 ? `${trialDaysLeft} day(s) left in your free trial.` : "Your trial has ended — choose a plan to continue."}
        </GlassCard>
      )}

      <div className="flex items-center justify-center gap-3 mb-10">
        <span className="text-sm" style={{ color: !yearly ? C.text : C.dim2, fontWeight: !yearly ? 600 : 400 }}>Monthly</span>
        <button onClick={() => setYearly((v) => !v)} className="w-12 h-7 rounded-full relative transition-colors" style={{ background: yearly ? C.blueA : "rgba(255,255,255,0.15)" }}>
          <span className="absolute top-0.5 w-6 h-6 rounded-full bg-white transition-transform" style={{ transform: yearly ? "translateX(22px)" : "translateX(2px)" }} />
        </button>
        <span className="text-sm" style={{ color: yearly ? C.text : C.dim2, fontWeight: yearly ? 600 : 400 }}>Yearly <span style={{ color: C.emerald }}>(save ~15%)</span></span>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-12">
        {PLANS.map((p) => (
          <PricingCard key={p.key} plan={p.plan} price={yearly ? p.yearly : p.monthly} features={p.features} best={p.best}
            current={user.subscription_plan === p.key && user.subscription_status === "active"} onSelect={() => setCheckoutPlan(p)} />
        ))}
      </div>

      <GlassCard className="p-6">
        <h2 className="text-lg font-bold mb-4 flex items-center gap-2" style={{ color: C.text }}><Lock className="w-4 h-4" style={{ color: C.blueA }} /> Locked behind subscription</h2>
        <div className="grid sm:grid-cols-2 gap-3">
          {LOCKED_FEATURES.map((f) => (
            <div key={f} className="flex items-center gap-2 text-sm" style={{ color: C.dim }}><Lock className="w-3.5 h-3.5" style={{ color: C.dim2 }} /> {f}</div>
          ))}
        </div>
      </GlassCard>

      <CheckoutModal
        open={!!checkoutPlan}
        price={checkoutPlan ? (yearly ? checkoutPlan.yearly : checkoutPlan.monthly) : 0}
        link={checkoutPlan ? (yearly ? checkoutPlan.stripe_link_yearly : checkoutPlan.stripe_link_monthly) : ""}
        onClose={() => setCheckoutPlan(null)}
        onConfirm={confirm}
      />
    </div>
  );
}

function CreatorBadges({ games }) {
  const totalViews = games.reduce((s, g) => s + (g.view_count || 0), 0);
  const totalDownloads = games.reduce((s, g) => s + (g.purchase_count || 0), 0);
  const badges = [
    { key: "published", label: "Rising Creator", icon: Rocket, earned: games.length >= 1, from: "#10b981", to: "#14b8a6" },
    { key: "views", label: "Popular Creator", icon: TrendingUp, earned: totalViews >= 100, from: C.blueB, to: C.blueA },
    { key: "downloads", label: "Top Seller", icon: Download, earned: totalDownloads >= 10, from: "#f59e0b", to: "#f97316" },
    { key: "prolific", label: "Community Favorite", icon: Trophy, earned: games.length >= 5, from: "#d946ef", to: "#ec4899" },
  ];
  const earned = badges.filter((b) => b.earned);
  if (!earned.length) return null;
  return (
    <div className="mb-10">
      <h2 className="text-lg font-bold mb-4" style={{ color: C.text }}>Badges</h2>
      <div className="flex flex-wrap gap-4">
        {earned.map((b) => (
          <GlassCard key={b.key} className="px-4 py-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0" style={{ backgroundImage: `linear-gradient(135deg, ${b.from}, ${b.to})` }}>
              <b.icon className="w-5 h-5 text-white" />
            </div>
            <span className="text-sm font-semibold" style={{ color: C.text }}>{b.label}</span>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

function ProfilePage({ user, myGames, go }) {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <GlassCard className="p-8 flex flex-col sm:flex-row items-center sm:items-start gap-6 mb-10">
        <div className="w-20 h-20 rounded-full flex items-center justify-center text-2xl font-black text-white shrink-0" style={gradBg}>
          {user.full_name?.[0]?.toUpperCase() || <UserIcon />}
        </div>
        <div className="flex-1 text-center sm:text-left">
          <h1 className="text-2xl font-black" style={{ color: C.text }}>{user.full_name}</h1>
          <p className="text-sm" style={{ color: C.dim }}>{user.email}</p>
          <div className="flex items-center justify-center sm:justify-start gap-2 mt-3">
            <Crown className="w-4 h-4" style={{ color: C.blueA }} />
            <span className="text-sm capitalize" style={{ color: "#c7cddb" }}>
              {user.subscription_status === "active" ? `${user.subscription_plan} plan` : user.subscription_status === "trial" ? "Free trial" : "No active subscription"}
            </span>
          </div>
        </div>
        <GhostButton onClick={() => go("home")} className="px-5 py-2.5 text-sm inline-flex items-center" style={{ color: "#c7cddb" }}>
          <LogOut className="w-4 h-4 mr-2" /> Log out
        </GhostButton>
      </GlassCard>

      <CreatorBadges games={myGames} />

      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold" style={{ color: C.text }}>My Published Games</h2>
        {myGames.length > 0 && (
          <GhostButton onClick={() => go("dashboard")} className="px-5 py-2.5 text-sm inline-flex items-center" style={{ color: "#c7cddb" }}>
            <LayoutDashboard className="w-4 h-4 mr-2" /> Creator Dashboard
          </GhostButton>
        )}
      </div>
      <GameSection games={myGames} go={go} />
      {myGames.length === 0 && <p className="text-center py-10" style={{ color: C.dim2 }}>You haven't published any games yet.</p>}
    </div>
  );
}

function CreatorDashboardPage({ myGames, go }) {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <button onClick={() => go("profile")} className="flex items-center gap-2 mb-6 text-sm" style={{ color: C.dim }}>
        <ArrowLeft className="w-4 h-4" /> Back
      </button>
      <h1 className="text-2xl font-black mb-8" style={{ color: C.text }}>Creator Dashboard</h1>
      {myGames.length === 0 ? (
        <p className="text-center py-10" style={{ color: C.dim2 }}>You haven't published any games yet.</p>
      ) : (
        <div className="space-y-3">
          {myGames.map((g) => (
            <GlassCard key={g.id} className="p-5 flex items-center gap-4">
              <img src={g.cover_image_url} alt={g.title} className="w-16 h-16 rounded-xl object-cover shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-semibold truncate" style={{ color: C.text }}>{g.title}</p>
                <p className="text-xs" style={{ color: C.dim }}>{g.category} · {g.type}</p>
              </div>
              <div className="flex items-center gap-2 text-sm" style={{ color: "#c7cddb" }}><Eye className="w-4 h-4" style={{ color: C.blueA }} /> {g.view_count || 0}</div>
              <div className="flex items-center gap-2 text-sm" style={{ color: "#c7cddb" }}><Download className="w-4 h-4" style={{ color: C.emerald }} /> {g.purchase_count || 0}</div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}

function MessageBubble({ message, isOwn }) {
  return (
    <div className={`flex ${isOwn ? "justify-end" : "justify-start"}`}>
      <div className="max-w-[75%] rounded-2xl px-4 py-2.5 text-sm" style={isOwn ? { ...gradBg, color: "#fff", borderBottomRightRadius: 4 } : { ...glass, color: "#dfe4ee", borderBottomLeftRadius: 4 }}>
        {message.content}
      </div>
    </div>
  );
}

function CommunityPage({ user, conversations, setConversations, publicChat, setPublicChat, go }) {
  const [tab, setTab] = useState("public");
  const [publicText, setPublicText] = useState("");
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [publicChat, tab]);

  const sendPublic = (e) => {
    e.preventDefault();
    if (!publicText.trim()) return;
    setPublicChat((prev) => [...prev, { id: `p_${Date.now()}`, sender_name: user.full_name, content: publicText }]);
    setPublicText("");
  };

  const otherName = (c) => {
    const idx = c.participant_ids.findIndex((id) => id !== user.id);
    return c.participant_names[idx] || "Member";
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-black" style={{ color: C.text }}>Community</h1>
        <p className="text-sm mt-1" style={{ color: C.dim }}>Chat publicly or message creators and members privately.</p>
      </div>

      <div className="flex gap-2 mb-6 rounded-full p-1 w-fit" style={glass}>
        {[["public", "Public Chat"], ["messages", "Private Messages"]].map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)} className="px-4 py-2 rounded-full text-sm font-medium transition-colors"
            style={tab === key ? { ...gradBg, color: "#fff" } : { color: C.dim }}>
            {label}
          </button>
        ))}
      </div>

      {tab === "public" && (
        <div>
          <div className="rounded-2xl p-4 mb-4 space-y-3 h-96 overflow-y-auto" style={glass}>
            {publicChat.map((m) => (
              <div key={m.id} className="flex gap-2">
                <span className="text-xs font-semibold shrink-0" style={{ color: C.blueA }}>{m.sender_name}</span>
                <span className="text-sm" style={{ color: "#dfe4ee" }}>{m.content}</span>
              </div>
            ))}
            <div ref={bottomRef} />
          </div>
          <form onSubmit={sendPublic} className="flex gap-2">
            <input value={publicText} onChange={(e) => setPublicText(e.target.value)} placeholder="Say something to the community..." className="flex-1 rounded-full px-5 py-3 text-sm outline-none" style={{ ...glass, color: C.text }} />
            <button type="submit" className="w-12 h-12 rounded-full flex items-center justify-center shrink-0" style={{ ...gradBg, ...glow }}>
              <Send className="w-5 h-5 text-white" />
            </button>
          </form>
        </div>
      )}

      {tab === "messages" && (
        <div>
          {conversations.length === 0 ? (
            <GlassCard className="text-center py-20">
              <MessageSquare className="w-10 h-10 mx-auto mb-3" style={{ color: C.dim2 }} />
              <p style={{ color: C.dim }}>No conversations yet.</p>
            </GlassCard>
          ) : (
            <div className="space-y-2">
              {conversations.map((c) => (
                <button key={c.id} onClick={() => go("conversation", { id: c.id })} className="w-full flex items-center justify-between rounded-2xl p-4 text-left" style={glass}>
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full flex items-center justify-center font-bold text-white shrink-0" style={gradBg}>
                      {otherName(c)?.[0]?.toUpperCase() || "?"}
                    </div>
                    <div>
                      <p className="font-semibold" style={{ color: C.text }}>{otherName(c)}</p>
                      <p className="text-sm truncate max-w-xs" style={{ color: C.dim }}>{c.last_message}</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4" style={{ color: C.dim2 }} />
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ConversationDetailPage({ id, user, conversations, setConversations, go }) {
  const conversation = conversations.find((c) => c.id === id);
  const [text, setText] = useState("");
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [conversation]);

  if (!conversation) return <div className="p-10" style={{ color: C.dim }}>Conversation not found.</div>;

  const otherName = () => {
    const idx = conversation.participant_ids.findIndex((pid) => pid !== user.id);
    return conversation.participant_names[idx] || "Member";
  };

  const send = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    const content = text;
    setText("");
    setConversations((prev) => prev.map((c) => c.id === id
      ? { ...c, last_message: content, last_message_at: new Date().toISOString(), messages: [...c.messages, { id: `cm_${Date.now()}`, sender_id: user.id, sender_name: user.full_name, content }] }
      : c));
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 flex flex-col" style={{ height: "85vh" }}>
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => go("community")} style={{ color: C.dim }}><ArrowLeft className="w-5 h-5" /></button>
        <h1 className="text-xl font-bold" style={{ color: C.text }}>{otherName()}</h1>
      </div>
      <div className="flex-1 overflow-y-auto space-y-3 rounded-2xl p-4 mb-4" style={glass}>
        {conversation.messages.map((m) => <MessageBubble key={m.id} message={m} isOwn={m.sender_id === user.id} />)}
        <div ref={bottomRef} />
      </div>
      <form onSubmit={send} className="flex gap-2">
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message..." className="flex-1 rounded-full px-5 py-3 outline-none" style={{ ...glass, color: C.text }} />
        <button type="submit" className="w-12 h-12 rounded-full flex items-center justify-center shrink-0" style={{ ...gradBg, ...glow }}>
          <Send className="w-5 h-5 text-white" />
        </button>
      </form>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  App shell                                                           */
/* ------------------------------------------------------------------ */
export default function GameVaultApp() {
  const [page, setPage] = useState("home");
  const [params, setParams] = useState({});
  const [games, setGames] = useState(seedGames);
  const [reviews, setReviews] = useState(seedReviews);
  const [purchases, setPurchases] = useState([]);
  const [user, setUser] = useState(initialUser);
  const [conversations, setConversations] = useState(seedConversations);
  const [publicChat, setPublicChat] = useState(seedPublicChat);
  const [toastState, setToastState] = useState(null);
  const toastTimer = useRef(null);

  const myGames = useMemo(() => games.filter((g) => g.creator_name === user.full_name), [games, user.full_name]);

  const toast = ({ title, description }) => {
    clearTimeout(toastTimer.current);
    setToastState({ title, description });
    toastTimer.current = setTimeout(() => setToastState(null), 2800);
  };

  const go = (p, prms = {}) => { setPage(p); setParams(prms); window.scrollTo?.({ top: 0 }); };

  const addGame = (game) => { setGames((prev) => [game, ...prev]); };
  const addReview = (gameId, review) => { setReviews((prev) => ({ ...prev, [gameId]: [review, ...(prev[gameId] || [])] })); };
  const addPurchase = (p) => { setPurchases((prev) => [...prev, p]); };

  let content;
  if (page === "home") content = <HomePage games={games} go={go} />;
  else if (page === "search") content = <SearchPage games={games} go={go} />;
  else if (page === "game-detail") content = <GameDetailPage id={params.id} games={games} setGames={setGames} reviews={reviews} addReview={addReview} currentUser={user} purchases={purchases} addPurchase={addPurchase} go={go} toast={toast} />;
  else if (page === "add-game") content = <AddGamePage addGame={addGame} currentUser={user} go={go} toast={toast} />;
  else if (page === "library") content = <LibraryPage games={games} purchases={purchases} currentUser={user} toast={toast} />;
  else if (page === "community") content = <CommunityPage user={user} conversations={conversations} setConversations={setConversations} publicChat={publicChat} setPublicChat={setPublicChat} go={go} />;
  else if (page === "conversation") content = <ConversationDetailPage id={params.id} user={user} conversations={conversations} setConversations={setConversations} go={go} />;
  else if (page === "subscription") content = <SubscriptionPage user={user} setUser={setUser} toast={toast} />;
  else if (page === "profile") content = <ProfilePage user={user} myGames={myGames} go={go} />;
  else if (page === "dashboard") content = <CreatorDashboardPage myGames={myGames} go={go} />;
  else content = <HomePage games={allGames} go={go} />;

  return (
    <div style={{ background: C.bg, minHeight: "100vh", fontFamily: "ui-sans-serif, system-ui, sans-serif" }}>
      <Toast toast={toastState} />
      <div className="flex">
        <SideNav page={page} go={go} />
        <main className="flex-1 min-w-0 pb-24 md:pb-0">{content}</main>
      </div>
      <BottomNav page={page} go={go} />
    </div>
  );
}

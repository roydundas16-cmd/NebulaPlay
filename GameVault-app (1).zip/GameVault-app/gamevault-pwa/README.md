# GameVault — installable app

This turns the GameVault artifact into a real installable app (a PWA), so it
opens in its own window with its own icon instead of living inside a browser
tab — like a native app, but it's still just a website under the hood.

## 1. Run it locally first (to try it)

You need [Node.js](https://nodejs.org) installed (18+).

```bash
cd gamevault-pwa
npm install
npm run dev
```

Open the URL it prints (usually `http://localhost:5173`). You'll see it
render like the normal web app — installing only becomes available once it's
served over HTTPS (see step 2).

## 2. Deploy it somewhere with HTTPS

Installable/"Add to Home Screen" behavior requires a real HTTPS URL — it
won't offer to install from `localhost`. Easiest free options:

- **Vercel**: `npm i -g vercel` then `vercel` inside the `gamevault-pwa` folder
- **Netlify**: drag-and-drop the `dist` folder (after `npm run build`) at
  https://app.netlify.com/drop
- **GitHub Pages**: push this folder to a repo and enable Pages

For a manual build:

```bash
npm run build     # outputs to dist/
npm run preview   # serve it locally to sanity-check before deploying
```

## 3. "Install" it like a real app

Once it's live on an HTTPS URL:

- **Desktop Chrome/Edge**: an install icon (⊕) appears in the address bar —
  click it. The app opens afterward in its own window, no address bar, no
  tabs, with the GameVault icon.
- **Android Chrome**: browser menu → "Install app" / "Add to Home screen".
  It gets a real home-screen icon and opens full-screen.
- **iOS Safari**: Share button → "Add to Home Screen". Opens full-screen
  from the home screen icon (iOS doesn't show a browser install prompt like
  Android/desktop, this is the equivalent).

## What's actually happening

- `vite-plugin-pwa` generates a web app manifest + service worker at build
  time, which is what makes browsers treat this as an installable app and
  lets it work offline after the first load.
- The icon comes from `public/icon-192.png` / `icon-512.png`.
- `index.html` has a small splash screen (the pulsing icon) shown for the
  brief moment before React mounts, so the launch feels instant rather than
  a blank white flash — the same trick real apps use.

## Notes

- This is the same GameVault app from before (mock local data, Stripe
  Payment Link checkout) — nothing about the app's functionality changed,
  only how it's packaged and launched.
- If you'd rather have a true native desktop app (a `.exe`/`.app` you
  double-click, using something like Electron or Tauri) instead of a PWA,
  that's also possible but is a heavier setup — let me know if you want
  that route instead.

# GameVault — full project

- `gamevault-pwa/` — the installable app itself (React + Vite + PWA).
  See `gamevault-pwa/README.md` for how to run it locally and deploy it
  so it can be installed like a real app.
- `payment-verification-backend/` — the small server-side code that will
  verify Stripe payments for real, once deployed and wired in.
  See `payment-verification-backend/README.md`.
